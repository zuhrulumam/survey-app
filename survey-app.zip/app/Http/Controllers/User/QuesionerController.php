<?php

namespace App\Http\Controllers\User;

use InfyOm\Generator\Controller\AppBaseController;
use App\Models\Questions;
use App\Models\Categories;
use App\Models\UserQuestions;
use App\Http\Requests\UserSendAnswers;

class QuesionerController extends AppBaseController {

    public function index() {
        return view("home");
    }

    public function getQuestions() {


        $questions = Questions::orderBy('question_id', 'ASC')->get();
        $totalQuestion = $questions->count();
        $perPage = 6;
        $totalPage = round($totalQuestion / $perPage);
        $categories = Categories::all();

//        $questions->setPath('question');
        return view('welcome', [
            'totalPage' => $totalPage,
            'perPage' => $perPage,
            'questions' => $questions,
            'categories' => $categories
        ]);
    }

    public function postQuestions(UserSendAnswers $request) {
        $data = $request->all();
//        print_r(array_keys($data));

        $dataKey = array_keys($data);
        
//        print_r($dataKey);

        $dataJawaban = [];
        $sumData = count($data);
        for ($i = 0; $i < $sumData-1; $i++) {
            $currId = explode("_", $dataKey[$i+1]);
            $currQuestionId = $currId[1] + 1;
            $currData = [
                "rel_user_id" => 1,
                "rel_question_id" => $currQuestionId,
                "rel_answer" => $data["pertanyaan_".$i]
            ];
            array_push($dataJawaban, $currData);
        }
        
//        print_r($dataJawaban);
        return view("success");
    }

    public function tryPost() {
        $dataJawaban = [];
        $data = [
            "rel_user_id" => 1,
            "rel_question_id" => 1,
            "rel_answer" => 3
        ];
        array_push($dataJawaban, $data);


        UserQuestions::insert($dataJawaban); //cari beda antara insert dengan save
    }

}
